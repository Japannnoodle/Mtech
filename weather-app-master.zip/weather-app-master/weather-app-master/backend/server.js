const express = require('express');
const dotenv = require('dotenv');
const axios = require('axios');
const cors = require('cors');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.post('/bylocation', async (req, res) => {
    const { latitude, longitude } = req.body;
    const date = new Date();
    if (!latitude || !longitude) {
        return res.status(400).json({ error: 'Latitude and Longitude are required' });
      }
      'https://api.open-meteo.com/v1/forecast?latitude=34.6275067&longitude=136.10845&current=temperature_2m&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset&timezone=auto&forecast_days=1'
    const apiKey = process.env.WEATHER_API_KEY; 

    const url2 = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&hourly=temperature_2m,weather_code&timezone=auto&start_date=${date.toISOString().split('T')[0]}&end_date=${date.toISOString().split('T')[0]}`
    try {
        let response = await axios.get(url1);
        const weatherData = response.data;
        response = await axios.get(url2);
        const { hourly } = response.data;
        res.json({
            city: weatherData.name,
            description: weatherData.weather[0].description,
            temperature: weatherData.main.temp,
            temp_min: weatherData.main.temp_min,
            temp_max: weatherData.main.temp_max,
            hourly: hourly,
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({error: 'Failed to fetch weather data'})
    }
});
app.post('/hourly', async (req, res) => {
    const { latitude, longitude } = req.body;
    if (!latitude || !longitude) {
        return res.status(400).json({ error: 'Latitude and Longitude are required' });
    }
    const cityUrl = `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json`
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,weather_code&hourly=temperature_2m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1`
    try {
        const cityNameRes = await axios.get(cityUrl);
        const { address } = cityNameRes.data;
        const response = await axios.get(url);
        const {current, hourly, daily} = response.data;
        res.json({
            current, hourly, daily, address
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({error: 'Failed to fetch weather data'})
    }
})
app.post('/weekly', async (req, res) => {
    const { latitude, longitude } = req.body;
    if (!latitude || !longitude) {
        return res.status(400).json({ error: 'Latitude and Longitude are required' });
    }
    const url1 = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto`;
    const url2 = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&daily=temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_probability_max&timezone=auto&forecast_days=1`
    const cityUrl = `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json`;
    try {
        const cityNameRes = await axios.get(cityUrl);
        const { address } = cityNameRes.data;
        const response1 = await axios.get(url1);
        const response2 = await axios.get(url2);
        const weekly = response1.data.daily;
        const dailyDetailInfo = response2.data.daily;
        res.json({
            weekly, dailyDetailInfo, address
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({error: 'Failed to fetch weather data'})
    }
});

app.get('/', (req, res) => {
    res.send('Weather App Backend is running!');
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
