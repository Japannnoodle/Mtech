import 'dart:convert';
import 'dart:io'; // SocketException-г барихад шаардлагатай
import 'package:flutter/material.dart';
import 'package:frontend/utils/helper_functions.dart';
import 'package:geolocator/geolocator.dart';
import '../widgets/custom_appbar.dart';
import '../widgets/glassy_card.dart';
import '../widgets/gradient_background.dart';
import 'package:http/http.dart' as http;

// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables
class SecondPage extends StatefulWidget {
  const SecondPage({super.key, required this.position});
  final Position position;

  @override
  State<SecondPage> createState() => _SecondPageState();
}

class _SecondPageState extends State<SecondPage> {
  double _temperatureMin = 0;
  double _temperatureMax = 0;
  String _cityName = 'Loading...';
  List<String> _times = [];
  List<double> _temperature_2m_maxs = [];
  List<double> _temperature_2m_mins = [];
  List<int> _weather_codes = [];
  bool _isLoading = true; // Өгөгдөл уншиж байгааг илэрхийлэх

  // Шинээр нэмэгдсэн хувьсагчид
  double _sunrise = 0; // Нар мандах цаг
  double _uvIndex = 0; // UV индекс
  double _airQuality = 0; // Агаарын чанар

  @override
  void initState() {
    super.initState();
    _getWeatherData(widget.position);
  }

  Future<void> _getWeatherData(Position position) async {
    const String url = 'http://10.0.2.2:3000/weekly'; // Серверийн URL

    try {
      final response = await http.post(
        Uri.parse(url),
        body: jsonEncode(
          {'latitude': position.latitude, 'longitude': position.longitude},
        ),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        var weatherData = jsonDecode(response.body);
        print(weatherData);
        setState(() {
          _temperatureMin =
              weatherData['dailyDetailInfo']['temperature_2m_min'][0];
          _temperatureMax =
              weatherData['dailyDetailInfo']['temperature_2m_max'][0];

          _times = List<String>.from(weatherData['weekly']['time']);
          _temperature_2m_maxs = List<double>.from(weatherData['weekly']
                  ['temperature_2m_max']
              .map((temp) => (temp as num).toDouble()));
          _temperature_2m_mins = List<double>.from(weatherData['weekly']
                  ['temperature_2m_min']
              .map((temp) => (temp as num).toDouble()));
          _weather_codes = List<int>.from(weatherData['weekly']['weather_code']
              .map((temp) => (temp as num).toInt()));
          _cityName = weatherData['address']['city'];

          // Шинээр нэмэгдсэн хувьсагчид
          _sunrise =
              weatherData['dailyDetailInfo']['sunrise'][0]; // Нар мандах цаг
          _uvIndex = weatherData['dailyDetailInfo']['uv_index'][0]; // UV индекс
          _airQuality =
              weatherData['dailyDetailInfo']['air_quality'][0]; // Агаарын чанар

          _isLoading = false;
        });
      } else {
        setState(() {
          _cityName = "Алдаа: ${response.statusCode}";
          _isLoading = false;
        });
      }
    } on SocketException catch (e) {
      print("SocketException: $e");
      setState(() {
        _cityName = "Сүлжээний алдаа!";
        _isLoading = false;
      });
    } catch (e) {
      print("Unknown error: $e");
      setState(() {
        _cityName = "Тодорхойгүй алдаа!";
        _isLoading = false;
      });
    }
  }

  String _getUVIndexDescription() {
    if (_uvIndex <= 2) {
      return "Хөнгөн. Нарны шил зүүх шаардлагагүй.";
    } else if (_uvIndex <= 5) {
      return "Орчны UV туяа нэмэгдэж, 20 минутын дараа нарны шил зүүх хэрэгтэй.";
    } else if (_uvIndex <= 7) {
      return "UV туяаны нөлөө их. Нарнаас хамгаалагч хэрэглэх.";
    } else if (_uvIndex <= 10) {
      return "Хүчилтөрөгчийн тунгалаг хамгаалалт шаардлагатай.";
    } else {
      return "Өндөр эрсдэлтэй. Гадаа гарахгүй байх хэрэгтэй.";
    }
  }

  // Нар мандах цагийг цаг, минут руу хөрвүүлэх
  String _formatTime(double timestamp) {
    DateTime date =
        DateTime.fromMillisecondsSinceEpoch((timestamp * 1000).toInt());
    return '${date.hour}:${date.minute < 10 ? '0' : ''}${date.minute}';
  }

  @override
  Widget build(BuildContext context) {
    return GradientBackground(
      child: _isLoading
          ? Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
            )
          : SingleChildScrollView(
              child: Column(
                children: [
                  CustomAppbar(),
                  Text(
                    _cityName,
                    style: TextStyle(
                      fontSize: 24,
                      color: Colors.white,
                      fontWeight: FontWeight.w300,
                    ),
                  ),
                  Text(
                    'Их: $_temperatureMax°   Бага: $_temperatureMin°',
                    style: TextStyle(
                      fontSize: 24,
                      color: Colors.white,
                      fontWeight: FontWeight.w300,
                    ),
                  ),
                  const Text(
                    '7 хоногийн мэдээлэл',
                    style: TextStyle(
                      fontSize: 24,
                      color: Colors.white,
                      fontWeight: FontWeight.w300,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: Column(
                      children: [
                        Container(
                            height: 180,
                            child: ListView.builder(
                                scrollDirection: Axis.horizontal,
                                itemCount: _times.length,
                                itemBuilder: (context, index) {
                                  DateTime date = DateTime.parse(_times[index]);
                                  String weekday = [
                                    'Ням',
                                    'Даваа',
                                    'Мягмар',
                                    'Лхагва',
                                    'Пүрэв',
                                    'Баасан',
                                    'Бямба'
                                  ][date.weekday % 7];
                                  return GlassyCard(
                                    margin: EdgeInsets.all(5),
                                    child: Column(
                                      children: [
                                        Text(
                                          "${_temperature_2m_maxs[index]}°C",
                                          style: TextStyle(
                                            fontSize: 20,
                                            color: Colors.white,
                                            fontWeight: FontWeight.w300,
                                          ),
                                        ),
                                        Image.asset(
                                          height: 60,
                                          width: 60,
                                          getWeatherImage(
                                              _weather_codes[index]),
                                        ),
                                        Text(
                                          weekday,
                                          style: TextStyle(
                                            fontSize: 20,
                                            color: Colors.white,
                                            fontWeight: FontWeight.w300,
                                          ),
                                        )
                                      ],
                                    ),
                                  );
                                })),
                        GlassyCard(
                          child: Container(
                            height: 250,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Агаарын чанар: $_airQuality',
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: Colors.white,
                                  ),
                                ),
                                Text(
                                  'UV индекс: $_uvIndex - ${_getUVIndexDescription()}',
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: Colors.white,
                                  ),
                                ),
                                Text(
                                  'Нар мандах цаг: ${_formatTime(_sunrise)} цаг',
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
