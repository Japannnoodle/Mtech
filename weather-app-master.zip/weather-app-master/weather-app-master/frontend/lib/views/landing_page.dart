// Тойм 7 хоногийн мэдээг дэлгэцлэх, тухайн байршлыг GPS ашиглан олох
// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'first_page.dart';
import 'second_page.dart';
import 'third_page.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  int _currentIndex = 0;
  Position? _currentPosition;

  void _onItemTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  void initState() {
    super.initState();
    _getCurrentLocationAndWeather();
  }

  Future<void> _getCurrentLocationAndWeather() async {
    // Request location permission
    PermissionStatus permission = await Permission.location.request();

    if (permission.isGranted) {
      // Get the current position
      LocationSettings locationSettings = LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 100,
      );
      Position position = await Geolocator.getCurrentPosition(
        locationSettings: locationSettings,
      );
      setState(() {
        _currentPosition = position;
      });
    }
  }

  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.pin_drop),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.thermostat),
            label: 'Дэлгэрэнгүй',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.map),
            label: 'Бүс нутгаар',
          )
        ],
        currentIndex: _currentIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped,
      ),
      body: _currentPosition == null
          ? Center(
              child: CircularProgressIndicator(),
            )
          : IndexedStack(index: _currentIndex, children: [
              FirstPage(position: _currentPosition!),
              SecondPage(position: _currentPosition!),
              ThirdPage(),
            ]),
    );
  }
}
