import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import '../utils/helper_functions.dart';
import '../widgets/custom_appbar.dart';
import '../widgets/glassy_card.dart';
import '../widgets/gradient_background.dart';
import 'package:http/http.dart' as http;
import 'dart:convert'; // For decoding JSON responses

// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables
class FirstPage extends StatefulWidget {
  const FirstPage({super.key, required this.position});
  final Position position;
  @override
  _FirstPageState createState() => _FirstPageState();
}

class _FirstPageState extends State<FirstPage> {
  String _cityName = 'loading...';
  int _description = -1;
  double _temperatureMin = 0;
  double _temperatureMax = 0;
  List<String> _times = [];
  List<double> _temperatures = [];
  List<int> _weather_code = [];

  @override
  void initState() {
    super.initState();
    _getWeatherData(widget.position);
  }

  // Function to send latitude and longitude to the backend and fetch weather data
  Future<void> _getWeatherData(Position position) async {
    const String url =
        'http://10.0.2.2:3000/hourly'; // Replace with your backend URL

    final response = await http.post(
      Uri.parse(url),
      body: jsonEncode(
          {'latitude': position.latitude, 'longitude': position.longitude}),
      headers: {'Content-Type': 'application/json'},
    );

    if (response.statusCode == 200) {
      var weatherData = jsonDecode(response.body);
      setState(() {
        _cityName = weatherData['address']['city'];
        _description = weatherData['daily']['weather_code'][0];
        _times = List<String>.from(weatherData['hourly']['time']);
        _weather_code = List<int>.from(weatherData['hourly']['weather_code']
            .map((temp) => (temp as num).toInt()));
        _temperatures = List<double>.from(weatherData['hourly']
                ['temperature_2m']
            .map((temp) => (temp as num).toDouble()));
        _temperatureMin =
            (weatherData['daily']['temperature_2m_min'][0] as num).toDouble();
        _temperatureMax =
            (weatherData['daily']['temperature_2m_max'][0] as num).toDouble();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    DateTime now = DateTime.now();
    String day = now.day.toString();
    String month = now.month.toString();
    String formattedDate = '$month сарын $day';
    return GradientBackground(
      child: SingleChildScrollView(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Column(
            children: [
              CustomAppbar(),
              Column(
                children: [
                  Image.asset(
                    height: 150,
                    width: 150,
                    getWeatherImage(_description),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    _cityName,
                    style: TextStyle(
                      fontSize: 24,
                      color: Colors.white,
                      fontWeight: FontWeight.w300,
                    ),
                  ),
                  Text(
                    getWeatherCondition(_description),
                    style: TextStyle(
                      fontSize: 24,
                      color: Colors.white,
                      fontWeight: FontWeight.w300,
                    ),
                  ),
                  Text(
                    'Их: $_temperatureMax°   Бага: $_temperatureMin°',
                    style: TextStyle(
                      fontSize: 24,
                      color: Colors.white,
                      fontWeight: FontWeight.w300,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Image.network(
                    height: 200,
                    width: 300,
                    'https://img.freepik.com/premium-photo/christmas-snow-house-tree_943840-177.jpg',
                  ),
                  GlassyCard(
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Text(
                              'Өнөөдөр',
                              style: TextStyle(
                                fontSize: 24,
                                color: Colors.white,
                                fontWeight: FontWeight.w300,
                              ),
                            ),
                            Text(
                              formattedDate,
                              style: TextStyle(
                                fontSize: 24,
                                color: Colors.white,
                                fontWeight: FontWeight.w300,
                              ),
                            ),
                          ],
                        ),
                        Divider(),
                        Container(
                          height: 150,
                          padding: EdgeInsets.only(top: 20),
                          child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            itemCount: _times.length,
                            itemBuilder: (context, index) {
                              return Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 8.0),
                                child: Column(
                                  children: [
                                    Text(
                                      "${_temperatures[index]}°C",
                                      style: TextStyle(
                                        fontSize: 20,
                                        color: Colors.white,
                                        fontWeight: FontWeight.w300,
                                      ),
                                    ),
                                    Image.asset(
                                      getWeatherImage(_weather_code[index]),
                                      height: 40,
                                      width: 40,
                                    ),
                                    Text(
                                      _times[index].substring(11, 16),
                                      style: TextStyle(
                                          fontSize: 20,
                                          color: Colors.white,
                                          fontWeight: FontWeight.w300),
                                    )
                                  ],
                                ),
                              );
                            },
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
            ],
          )
        ]),
      ),
    );
  }
}
