import 'package:flutter/material.dart';
import '../widgets/custom_appbar.dart';
import '../widgets/gradient_background.dart';
import '../widgets/province_card.dart';

class ThirdPage extends StatefulWidget {
  const ThirdPage({super.key});

  @override
  State<ThirdPage> createState() => _ThirdPageState();
}

class _ThirdPageState extends State<ThirdPage> {
  // Бүх хотуудын жагсаалт
  final List<Map<String, dynamic>> cities = [
    {
      "city": "Ulaanbaatar",
      "province": "Mongolia",
      "weatherDescription": "Sunny",
      "weatherIcon": 'images/sunny.png',
      "currentTemp": 22.0,
      "maxTemp": 28.0,
      "minTemp": 15.0,
    },
    {
      "city": "Tokyo",
      "province": "Japan",
      "weatherDescription": "Cloudy",
      "weatherIcon": 'images/cloudy.png',
      "currentTemp": 18.5,
      "maxTemp": 21.0,
      "minTemp": 16.0,
    },
    {
      "city": "New York",
      "province": "USA",
      "weatherDescription": "Rainy",
      "weatherIcon": 'images/rainy.png',
      "currentTemp": 12.2,
      "maxTemp": 14.8,
      "minTemp": 10.0,
    },
    {
      "city": "Paris",
      "province": "France",
      "weatherDescription": "Windy",
      "weatherIcon": 'images/windy.png',
      "currentTemp": 15.3,
      "maxTemp": 17.6,
      "minTemp": 12.1,
    },
    {
      "city": "Sydney",
      "province": "Australia",
      "weatherDescription": "Sunny",
      "weatherIcon": 'images/sunny.png',
      "currentTemp": 25.0,
      "maxTemp": 30.5,
      "minTemp": 20.0,
    },
  ];

  // Хайлтын дараах шүүгдсэн жагсаалт
  List<Map<String, dynamic>> filteredCities = [];

  @override
  void initState() {
    super.initState();
    // Анх эхлэх үед бүх хотуудыг харуулна
    filteredCities = cities;
  }

  @override
  Widget build(BuildContext context) {
    return GradientBackground(
      child: Column(
        children: [
          CustomAppbar(),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 16),
            margin: EdgeInsets.symmetric(horizontal: 20),
            decoration: BoxDecoration(
              color: Color.fromARGB(100, 0, 0, 0), // Search bar-ийн өнгө
              borderRadius: BorderRadius.circular(16), // Дугуй булан
            ),
            child: TextField(
              decoration: InputDecoration(
                hintText: "Search city...",
                border: InputBorder.none,
                icon: Icon(Icons.search),
                hintStyle: TextStyle(
                  fontSize: 18,
                  color: Colors.white,
                  fontWeight: FontWeight.w500,
                ),
              ),
              onChanged: (value) {
                // Хайлтын утгаар жагсаалтыг шүүх
                setState(() {
                  filteredCities = cities
                      .where((city) => city["city"]
                          .toLowerCase()
                          .contains(value.toLowerCase()))
                      .toList();
                });
              },
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: filteredCities.length,
              itemBuilder: (context, index) {
                final city = filteredCities[index];
                return Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: WeatherCard(
                    city: city["city"],
                    province: city["province"],
                    weatherDescription: city["weatherDescription"],
                    weatherIcon: city["weatherIcon"],
                    currentTemp: city["currentTemp"],
                    maxTemp: city["maxTemp"],
                    minTemp: city["minTemp"],
                  ),
                );
              },
            ),
          )
        ],
      ),
    );
  }
}
