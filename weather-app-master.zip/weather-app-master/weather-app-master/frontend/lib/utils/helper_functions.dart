// weather_utils.dart

String getWeatherCondition(int weatherCode) {
  if (weatherCode == 0 || weatherCode == 1) {
    return 'Цэлмэг'; // Clear sky and mainly clear
  } else if (weatherCode == 2 || weatherCode == 3) {
    return 'Багавтар үүлтэй'; // Partly cloudy
  } else if (weatherCode == 45 || weatherCode == 48) {
    return 'Манантай'; // Fog
  } else if (weatherCode == 60 ||
      weatherCode == 61 ||
      weatherCode == 63 ||
      weatherCode == 65 ||
      weatherCode == 51) {
    return 'Бороотой'; // Rainy
  } else if (weatherCode == 71 ||
      weatherCode == 73 ||
      weatherCode == 75 ||
      weatherCode == 77) {
    return 'Цастай'; // Snow
  } else if (weatherCode == 80 || weatherCode == 81 || weatherCode == 82) {
    return 'Шиврээ бороо'; // Showers
  } else if (weatherCode == 95 || weatherCode == 96 || weatherCode == 99) {
    return 'Аянга цахилгаантай бороо'; // Thunderstorms
  } else {
    return 'Тодорхойгүй цаг агаар'; // Unknown weather
  }
}

String getWeatherImage(int weatherCode) {
  if (weatherCode == 0 || weatherCode == 1) {
    return 'images/sunny.png'; // Clear sky and mainly clear
  } else if (weatherCode == 2 || weatherCode == 3) {
    return 'images/cloudy.png'; // Partly cloudy and mostly cloudy
  } else if (weatherCode == 45 || weatherCode == 48) {
    return 'images/foggy.png'; // Fog
  } else if (weatherCode == 60 ||
      weatherCode == 61 ||
      weatherCode == 63 ||
      weatherCode == 65 ||
      weatherCode == 51) {
    return 'images/rainy.png'; // Light to heavy rain
  } else if (weatherCode == 71 ||
      weatherCode == 73 ||
      weatherCode == 75 ||
      weatherCode == 77) {
    return 'images/snowy.png'; // Snow
  } else if (weatherCode == 80 || weatherCode == 81 || weatherCode == 82) {
    return 'images/rainy.png'; // Showers
  } else if (weatherCode == 95 || weatherCode == 96 || weatherCode == 99) {
    return 'images/windy.png'; // Thunderstorms
  } else {
    return 'images/unknown.png'; // For unknown or undefined weather codes
  }
}
